﻿using System;

namespace ConsoleApp7
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintBuffer printBuffer = PrintBuffer.Instance;
            printBuffer.AddPrintJob("Dokument1.pdf");
            printBuffer.AddPrintJob("Dokument2.pdf");
            printBuffer.AddPrintJob("Dokument3.pdf");

            printBuffer.ProcessPrintJobs();
        }
    }
}
