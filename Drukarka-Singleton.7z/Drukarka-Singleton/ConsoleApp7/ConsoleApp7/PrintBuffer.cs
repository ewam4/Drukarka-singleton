﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    public class PrintBuffer
    {
        private static PrintBuffer _instance;
        private static readonly object _lock = new object();
        private Queue<string> printQueue = new Queue<string>();

   
        private PrintBuffer() { }


        public static PrintBuffer Instance
        {
            get
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new PrintBuffer();
                    }
                    return _instance;
                }
            }
        }


        public void AddPrintJob(string document)
        {
            lock (_lock)
            {
                printQueue.Enqueue(document);
                Console.WriteLine($"Dodano dokument do wydruku: {document}");
            }
        }


        public void ProcessPrintJobs()
        {
            lock (_lock)
            {
                while (printQueue.Count > 0)
                {
                    string document = printQueue.Dequeue();
                    Console.WriteLine($"Drukowanie dokumentu: {document}");

                }
            }
        }
    }
}
